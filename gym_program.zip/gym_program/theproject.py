class planes:
    def nombreDePlan(self):
        self.nombre_del_plan  
          
    def HorasDelPlan(self):
        self.horas_del_plan