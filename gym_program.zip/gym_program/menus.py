class Menu:
    """ this class is for the menus"""
    
    def menuPrincipal():
        print("""                   ===MENÚ PRINCIPAL===
              1. catalogo
              2. Registro de ingresos por mes
              3. tercera opcion que no tengo muy clara 
              4. pruebas :)
              5. salir del programa\n""")
        
    def subMenu1():
         print("""
                               ===MENÚ DE MANTENIMIENTO===
              1. Instructor
              2. Planes de subscripción
              3. Clientes
              4. regresar\n""")
         
    def subMenu2():
         print("""1. Crear 
             2. ver 
             3. Modificar
             4. Eliminar
             5. Regresar\n""")
         
    def subMenuCatalogoInstructor():
        print("""
              ¡Bienvenidos a Instructor!\n
              
              1.Crear
              2.ver Instructor
              3.Modificar
              4.eliminar
              5.regresar
              """)
        
    def subMenuCatalogoSubscripcion():
         print("""
              ¡Bienvenidos a planes de subscripcion!\n
    
              1.Crear
              2.ver subscrip
              3.Modificar
              4.eliminar
              5.regresar
              """)
    def alertaDeExepcion():
         print("""
               escribiste un numero mal
               """)
         
    def subMenuEntradaCliente():
         print("""
                      has entrado al menu 3
                      1. crear cliente con id
                      2. ver clientes
                      3. actualizar clientes
                      4. eliminar clientes
                      5.salir
                      """)
         
     
          
          
    def subMenuCatalogoCliente():
         print("""
              ¡Bienvenidos a Clientes!\n
    
                    has entrado al menu 3
                      1. crear cliente con id
                      2. ver clientes
                      3. actualizar clientes
                      4. eliminar clientes
                      5.salir
              """)
        